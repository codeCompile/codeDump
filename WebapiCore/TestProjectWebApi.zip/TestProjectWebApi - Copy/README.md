# CRUD.With.VSCode.EF
In this article I am going to explain how to create a basic web application using ASP.Net Core MVC and Visual Studio Code in Windows System. We are going to create a sample Companies database management system.

We will be using ASP.Net Core 2.0,Entity Framework and SQLite.
# Read the full article at
http://ankitsharmablogs.com/crud-operation-asp-net-core-mvc-using-visual-studio-code-ef/
